import { FunctionComponent, PropsWithChildren } from "react"

export type AppContextProviderComponent = FunctionComponent<PropsWithChildren<unknown>>
